
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alli959',
  applicationName: 'lesapp-data',
  appUid: 'DNFvm7G6qNnCYR96nJ',
  orgUid: 'd568e117-023f-4511-babe-23ddbd7d59ff',
  deploymentUid: 'a01cbb94-2189-4eef-8891-59ee60a6fb68',
  serviceName: 'lesapp-data',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'lesapp-data-dev-speak', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.speak, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}