
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alli959',
  applicationName: 'lesapp-data',
  appUid: 'DNFvm7G6qNnCYR96nJ',
  orgUid: 'd568e117-023f-4511-babe-23ddbd7d59ff',
  deploymentUid: '72352a15-7003-4de8-9366-a94e374b8fb8',
  serviceName: 'lesapp-data',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'lesapp-data-dev-get', timeout: 15 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.get, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}