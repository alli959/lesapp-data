
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alli959',
  applicationName: 'lesapp-data',
  appUid: 'DNFvm7G6qNnCYR96nJ',
  orgUid: 'd568e117-023f-4511-babe-23ddbd7d59ff',
  deploymentUid: '8ab42760-b75a-43c8-bee6-050d24f9fb5f',
  serviceName: 'lesapp-data',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'lesapp-data-dev-auth', timeout: 6 };

try {
  const userHandler = require('./auth.js');
  module.exports.handler = serverlessSDK.handler(userHandler.auth, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}